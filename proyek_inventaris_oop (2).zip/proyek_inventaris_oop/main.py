# TUGAS KELOMPOK 02.1 - ENKAPSULASI DAN ABSTRAKSI
# Program: Aplikasi Inventaris Barang Berbasis Integritas Data
# Matakuliah: Pemrograman Berorientasi Objek (OOP)

# ANGGOTA TIM:
# 1. Fitri Khairani Sitorus (12550120344)
# 2. [Nama Mahasiswa 2]      ()
# 3. [Nama Mahasiswa 3]      ()
# 4. [Nama Mahasiswa 4]      ()
# =================================================================

from models import Barang, Transaksi, User
from manager import InventoryManager

def main():
    # 1. Simulasi Login User 
    user_aktif = User("Fitri_Admin", "rahasia123", "Administrator")
    user_aktif.login()

    # 2. Inisialisasi Manager
    manager = InventoryManager()

    # 3. OPERASI PENAMBAHAN 
    print("\n--- Tahap 1: Penambahan Barang ---")
    b1 = Barang("B001", "Laptop ASUS", 10, 12000000, "Elektronik")
    b2 = Barang("B002", "Mouse Wireless", 50, 250000, "Elektronik")
    
    manager.tambah_barang(b1)
    manager.tambah_barang(b2)
    manager.lihat_semua_stok()

    # 4. OPERASI PEMBARUAN 
    print("--- Tahap 2: Pembaruan Stok & Harga ---")
    b1.update_stok(5)      # Stok masuk
    b1.set_harga(12500000) # Harga naik
    
    # Simpan log aktivitas (Sesuai Tabel: Transaksi)
    log = Transaksi("TR001", "Update Barang B001", 5)
    log.simpan_log()

    # 5. OPERASI PENGHAPUSAN
    print("\n--- Tahap 3: Penghapusan Barang ---")
    # Kita hapus Mouse Wireless (B002)
    manager.hapus_barang("B002")
    
    # 6. LIHAT LAPORAN AKHIR
    manager.lihat_semua_stok()

if __name__ == "__main__":
    main()