
from models import Barang

# KELAS PENGELOLA (INVENTORY MANAGER)
class InventoryManager:
    def __init__(self):
        self.__daftar_barang = []

    def tambah_barang(self, barang):
        if isinstance(barang, Barang):
            self.__daftar_barang.append(barang)
            print(f"Sistem: Barang '{barang.nama}' didaftarkan.")

    def hapus_barang(self, id_target):
        # Mencari dan menghapus barang dari list berdasarkan ID-nya
        sebelum = len(self.__daftar_barang)
        self.__daftar_barang = [b for b in self.__daftar_barang if b.id_barang != id_target]
        
        if len(self.__daftar_barang) < sebelum:
            print(f"Sistem: Barang dengan ID '{id_target}' berhasil dihapus.")
        else:
            print(f"[PERINGATAN] ID '{id_target}' tidak ditemukan!")

    def lihat_semua_stok(self):
        # Tambahan validasi jika stok kosong
        if not self.__daftar_barang:
            print("\n" + "="*85)
            print(f"{'LAPORAN KOSONG - TIDAK ADA DATA':^85}")
            print("="*85 + "\n")
            return

        print("\n" + "="*85)
        print(f"{'LAPORAN INVENTARIS BARANG':^85}")
        print("="*85)
        for item in self.__daftar_barang:
            print(item.tampilkan_detail())
        print("="*85 + "\n")