from abc import ABC, abstractmethod

# 1. KELAS ITEMBASE (ABC) 
class ItemBase(ABC):
    def __init__(self, id_barang, nama):
        self.__id_barang = id_barang # Private
        self.__nama = nama           # Private

    @property
    def id_barang(self): return self.__id_barang

    @property
    def nama(self): return self.__nama

    @abstractmethod
    def tampilkan_detail(self):
        """Metode ini wajib diimplementasikan oleh setiap jenis barang"""
        pass