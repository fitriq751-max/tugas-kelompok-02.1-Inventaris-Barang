# 2. KELAS FINANSIALMIXIN 
class FinansialMixin:
    def hitung_ppn(self, harga):
        return harga * 0.11 # PPN 11%

    def hitung_total_aset(self, harga, stok):
        return harga * stok