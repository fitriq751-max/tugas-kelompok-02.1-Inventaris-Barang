from base import ItemBase
from mixins import FinansialMixin
from datetime import datetime

# 3. KELAS BARANG 
class Barang(ItemBase, FinansialMixin):
    def __init__(self, id_barang, nama, stok, harga, kategori):
        super().__init__(id_barang, nama)
        self.__stok = stok
        self.__harga = harga
        self.__kategori = kategori

    def set_harga(self, harga_baru):
        if harga_baru > 0:
            self.__harga = harga_baru
            print(f"Sistem: Harga '{self.nama}' berhasil diperbarui.")
        else:
            print(f"[PERINGATAN] Harga tidak valid!")

    def update_stok(self, jumlah):
        if (self.__stok + jumlah) >= 0:
            self.__stok += jumlah
            status = "Masuk" if jumlah > 0 else "Keluar"
            print(f"Sistem: Stok {status} ({abs(jumlah)} unit) untuk '{self.nama}'.")
        else:
            print(f"[ERROR] Stok '{self.nama}' tidak mencukupi!")

    def tampilkan_detail(self):
        ppn = self.hitung_ppn(self.__harga)
        total_aset = self.hitung_total_aset(self.__harga, self.__stok)
        return (f"ID: {self.id_barang} | Nama: {self.nama:15} | "
                f"Stok: {self.__stok:3} | Harga+PPN: Rp{self.__harga + ppn:,.0f} | "
                f"Nilai Aset: Rp{total_aset:,.0f}")

# 4. KELAS TRANSAKSI  
class Transaksi:
    def __init__(self, id_tr, jenis, jumlah):
        self.__id_tr = id_tr
        self.__jenis = jenis
        self.__jumlah = jumlah
        self.__tgl = datetime.now().strftime("%d-%m-%Y %H:%M")

    def simpan_log(self):
        print(f"Log Transaksi: [ID {self.__id_tr}] {self.__jenis} sebanyak {self.__jumlah} unit pada {self.__tgl}")

# 5. KELAS USER 
class User:
    def __init__(self, username, password, role):
        self.__username = username
        self.__password = password
        self.__role = role

    def login(self):
        print(f"Sistem: User '{self.__username}' ({self.__role}) berhasil login.")